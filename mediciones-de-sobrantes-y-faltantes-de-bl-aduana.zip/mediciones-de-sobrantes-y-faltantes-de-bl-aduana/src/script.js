// Función para calcular los totales y mostrar los resultados
function generateReport() {
  // Obtener los datos del formulario
  const manifestedBarrels1 = parseFloat(document.getElementById("manifested-barrels-1").value);
  const manifestedTonnes1 = parseFloat(document.getElementById("manifested-tonnes-1").value);
  const dischargedBarrels1 = parseFloat(document.getElementById("discharged-barrels-1").value);
  const dischargedTonnes1 = parseFloat(document.getElementById("discharged-tonnes-1").value);

  // Calcular las diferencias entre las cantidades manifestadas y descargadas
  const differenceBarrels1 = dischargedBarrels1 - manifestedBarrels1;
  const differenceTonnes1 = dischargedTonnes1 - manifestedTonnes1;

  // Calcular las sumas totales de las cantidades manifestadas y recibidas
  const totalManifestedBarrels = manifestedBarrels1;
  const totalManifestedTonnes = manifestedTonnes1;
  const totalReceivedBarrels = dischargedBarrels1;
  const totalReceivedTonnes = dischargedTonnes1;

  // Calcular las sumas totales de las cantidades en faltante y sobrante
  const totalShortageBarrels = Math.max(0, -differenceBarrels1);
  const totalShortageTonnes = Math.max(0, -differenceTonnes1);
  const totalSurplusBarrels = Math.max(0, differenceBarrels1);
  const totalSurplusTonnes = Math.max(0, differenceTonnes1);

  // Mostrar los resultados en la página
  document.getElementById("total-manifested-barrels").innerText = totalManifestedBarrels.toFixed(2);
  document.getElementById("total-manifested-tonnes").innerText = totalManifestedTonnes.toFixed(2);
  document.getElementById("total-received-barrels").innerText = totalReceivedBarrels.toFixed(2);
  document.getElementById("total-received-tonnes").innerText = totalReceivedTonnes.toFixed(2);
  document.getElementById("total-shortage-barrels").innerText = totalShortageBarrels.toFixed(2);
  document.getElementById("total-shortage-tonnes").innerText = totalShortageTonnes.toFixed(2);
  document.getElementById("total-surplus-barrels").innerText = totalSurplusBarrels.toFixed(2);
  document.getElementById("total-surplus-tonnes").innerText = totalSurplusTonnes.toFixed(2);
}

// Función para limpiar los campos del formulario y los resultados
function clearForm() {
  document.getElementById("cargo-form").reset();
  document.getElementById("total-manifested-barrels").innerText = "0.00";
  document.getElementById("total-manifested-tonnes").innerText = "0.00";
  document.getElementById("total-received-barrels").innerText = "0.00";
  document.getElementById("total-received-tonnes").innerText = "0.00";
  document.getElementById("total-shortage-barrels").innerText = "0.00";
  document.getElementById("total-shortage-tonnes").innerText = "0.00";
  document.getElementById("total-surplus-barrels").innerText = "0.00";
  document.getElementById("total-surplus-tonnes").innerText = "0.00";
}

// Función para cambiar al tema oscuro
function toggleDarkMode() {
  document.body.classList.add("dark-mode");
}

// Función para cambiar al tema claro
function toggleLightMode() {
  document.body.classList.remove("dark-mode");
}

// Event listener para el botón "Generar"
document.getElementById("cargo-form").addEventListener("submit", function (event) {
  event.preventDefault();
  generateReport();
});

// Event listener para el botón "Limpiar"
document.getElementById("cargo-form").addEventListener("reset", function (event) {
  event.preventDefault();
  clearForm();
});
