# Mediciones de sobrantes y faltantes de BL Aduana

A Pen created on CodePen.io. Original URL: [https://codepen.io/Serponge777/pen/dyQwJoK](https://codepen.io/Serponge777/pen/dyQwJoK).

